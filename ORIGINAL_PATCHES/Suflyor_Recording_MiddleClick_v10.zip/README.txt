Suflyor UI status and middle mouse fix v10

1. The status indicator reads "recording" only if the Start/Stop session
   timer is active. Enabled Mic/System sources alone show "idle".
2. Native Windows WM_MBUTTONUP closes a tile through its existing close-clicked
   handler (without affecting left-click or wheel scrolling). A Winit fallback
   stays in place if native installation is unavailable.
3. No HTTP/STT/AI/network behavior changed. No Cargo cache deletion.
4. The installer applies only two source files, creates backups and rolls
   them back if the build fails.
5. After a successful debug build it launches overlay-host.exe.

Windows build/runtime tests were not possible in the Linux workspace.
Source patch and reverse checks passed on v8.2 and v9 source snapshots.
