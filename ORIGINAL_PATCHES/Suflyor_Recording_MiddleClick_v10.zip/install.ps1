﻿param([string]$ProjectRoot = "")
$ErrorActionPreference = "Stop"

if (-not $ProjectRoot) {
    $docs = [Environment]::GetFolderPath('MyDocuments')
    $known = Join-Path $docs 'Suflyor-Recovered-v8-20261027-003608'
    if ((Test-Path (Join-Path $known 'slint-experiment\Cargo.toml')) -and
        (Test-Path (Join-Path $known 'overlay-backend\Cargo.toml'))) {
        $ProjectRoot = $known
    } else {
        $candidates = @(Get-ChildItem $docs -Directory -Filter 'Suflyor-Recovered*' -ErrorAction SilentlyContinue |
            Where-Object {
                (Test-Path (Join-Path $_.FullName 'slint-experiment\Cargo.toml')) -and
                (Test-Path (Join-Path $_.FullName 'overlay-backend\Cargo.toml'))
            })
        if ($candidates.Count -eq 1) { $ProjectRoot = $candidates[0].FullName }
        elseif ($candidates.Count -gt 1) { throw 'Multiple Suflyor projects found. Pass -ProjectRoot explicitly.' }
    }
}
if (-not $ProjectRoot) { throw 'Suflyor sources not found. Pass -ProjectRoot.' }
$ProjectRoot = [IO.Path]::GetFullPath($ProjectRoot)
$patch = Join-Path $PSScriptRoot 'status-middleclick-v10.patch'
$files = @(
    'slint-experiment\src\bin\overlay_host\bar_tray.rs',
    'slint-experiment\src\bin\overlay_host\tile_window.rs'
)
foreach ($p in @('slint-experiment\Cargo.toml','overlay-backend\Cargo.toml') + $files) {
    if (-not (Test-Path (Join-Path $ProjectRoot $p) -PathType Leaf)) {
        throw "Missing required project file: $p"
    }
}
if (Get-Process -Name 'overlay-host' -ErrorAction SilentlyContinue) {
    throw 'Close Suflyor (overlay-host.exe) before installing.'
}
$git = (Get-Command git.exe -ErrorAction Stop).Source
$cargo = (Get-Command cargo.exe -ErrorAction Stop).Source
$backup = Join-Path $ProjectRoot ('patch-backups\status-middleclick-v10-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach ($f in $files) {
    $target = Join-Path $backup $f
    New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $ProjectRoot $f) -Destination $target -Force
}
$changed = $false
try {
    # Apply the patch to the existing source files; do not reapply previous
    # patches and do not touch the Cargo target cache or user config.
    $ErrorActionPreference = 'Continue'
    & $git -C $ProjectRoot apply --reverse --check --ignore-whitespace $patch 2>$null | Out-Null
    $installed = $LASTEXITCODE -eq 0
    if (-not $installed) {
        & $git -C $ProjectRoot apply --check --ignore-whitespace $patch 2>&1 | Out-Host
        if ($LASTEXITCODE -ne 0) { throw 'Patch incompatible with selected source tree; no changes applied.' }
        & $git -C $ProjectRoot apply --ignore-whitespace $patch 2>&1 | Out-Host
        if ($LASTEXITCODE -ne 0) { throw 'Patch failed' }
        $changed = $true
        Write-Host 'Source fix installed.' -ForegroundColor Green
    } else {
        Write-Host 'Source fix already present.' -ForegroundColor Yellow
    }
    $ErrorActionPreference = 'Stop'
    $env:CARGO_INCREMENTAL = '1'
    $env:CARGO_BUILD_JOBS = '2'
    $projectSlint = Join-Path $ProjectRoot 'slint-experiment'
    Push-Location $projectSlint
    try {
        $ErrorActionPreference = 'Continue'
        & $cargo build --bin overlay-host --jobs 2
        $code = $LASTEXITCODE
    } finally { Pop-Location; $ErrorActionPreference = 'Stop' }
    if ($code -ne 0) { throw "Cargo failed (exit $code)" }
    $exe = Join-Path $ProjectRoot 'slint-experiment\target\debug\overlay-host.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw "EXE not found: $exe" }
    Write-Host "Installed: $exe" -ForegroundColor Green
    Write-Host "Backup: $backup" -ForegroundColor Cyan
    Start-Process -FilePath $exe
}
catch {
    if ($changed) {
        foreach ($f in $files) {
            Copy-Item -LiteralPath (Join-Path $backup $f) -Destination (Join-Path $ProjectRoot $f) -Force
        }
        Write-Warning 'Rust/Slint source files rolled back; Cargo cache remains intact.'
    }
    throw
}
