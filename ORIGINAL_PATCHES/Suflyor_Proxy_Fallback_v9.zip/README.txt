Suflyor Cloud Proxy / Network Fallback v9

Based on Suflyor-Recovered-v8-20261027-003608 source snapshot.

Settings -> AI bridge -> Network proxy / fallback.

Modes:
0 System proxy (original behavior)
1 Direct, retry via configured proxy if network fails
2 Proxy, retry direct if proxy fails
3 Direct only (ignore system proxies)
4 Proxy only

Use HTTP(S) or SOCKS5 proxy URL, e.g. http://127.0.0.1:7890
Fallback handles connection/timeout errors and 403,407,502,503,504.
No fallback for HTTP 400, 401, 429, successful responses, or mid-stream interruptions.
Local and private network endpoints are always direct.
Scope: cloud AI (including Codex Direct) + Groq, ElevenLabs, Speechmatics,
Deepgram and cloud Whisper STT paths; NOT native Codex App Server,
external browsers, OS updates, or other sidecars.

Proxy URL is stored in config.json. Do not include a proxy password in the URL
unless you accept local at-rest exposure. The proxy URL is not logged.

Run install.ps1 from Windows PowerShell. Backup is taken before changes.
Installer rolls back source files on failed patch or compilation.
Cargo cache is not cleaned.

Validation on build machine: diff apply/reverse check only; Windows compilation
and live provider requests not verified.
