﻿param([string]$ProjectRoot = "")
$ErrorActionPreference = "Stop"

$patch = Join-Path $PSScriptRoot "proxy-fallback-v9.patch"
if (!(Test-Path -LiteralPath $patch)) { throw "Patch file missing" }

if (!$ProjectRoot) {
    $preferred = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Suflyor-Recovered-v8-20261027-003608'
    if (Test-Path (Join-Path $preferred 'overlay-backend\Cargo.toml')) {
        $ProjectRoot = $preferred
    } else {
        $candidates = @(
            Get-ChildItem ([Environment]::GetFolderPath('MyDocuments')) -Directory -Filter 'Suflyor-Recovered-v8*' -ErrorAction SilentlyContinue |
                Where-Object { Test-Path (Join-Path $_.FullName 'overlay-backend\Cargo.toml') } |
                Sort-Object LastWriteTime -Descending
        )
        if ($candidates.Count -eq 1) { $ProjectRoot = $candidates[0].FullName }
        elseif ($candidates.Count -gt 1) {
            throw "Multiple source projects found; run install.ps1 -ProjectRoot 'C:\path\to\project'"
        }
    }
}
if (!$ProjectRoot) { throw "Suflyor source project not found; pass -ProjectRoot" }
$ProjectRoot = [IO.Path]::GetFullPath($ProjectRoot)
if (!(Test-Path (Join-Path $ProjectRoot 'overlay-backend\Cargo.toml')) -or
    !(Test-Path (Join-Path $ProjectRoot 'slint-experiment\Cargo.toml')) -or
    !(Test-Path (Join-Path $ProjectRoot 'slint-experiment\ui\settings_panel.slint'))) {
    throw "Incomplete source tree: $ProjectRoot"
}
if (Get-Process -Name 'overlay-host' -ErrorAction SilentlyContinue) {
    throw "Close running overlay-host.exe before building"
}
$git = (Get-Command git.exe -ErrorAction Stop).Source
$cargo = (Get-Command cargo.exe -ErrorAction Stop).Source

$relative = @(
    'overlay-backend\Cargo.toml',
    'overlay-backend\src\config.rs',
    'overlay-backend\src\lib.rs',
    'overlay-backend\src\network.rs',
    'overlay-backend\src\ai\completion.rs',
    'overlay-backend\src\ai\stream.rs',
    'overlay-backend\src\ai\inspect.rs',
    'overlay-backend\src\stt.rs',
    'overlay-backend\src\codex_direct.rs',
    'slint-experiment\ui\settings_panel.slint',
    'slint-experiment\src\bin\overlay_host\settings_controller.rs',
    'slint-experiment\Cargo.lock'
)
$backup = Join-Path $ProjectRoot ('patch-backups\proxy-v9-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
$existing = @()
foreach ($rel in $relative) {
    $source = Join-Path $ProjectRoot $rel
    if (Test-Path -LiteralPath $source -PathType Leaf) {
        $dest = Join-Path $backup $rel
        New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $dest -Force
        $existing += $rel
    }
}
function Restore-OriginalFiles {
    foreach ($rel in $relative) {
        $target = Join-Path $ProjectRoot $rel
        if ($existing -contains $rel) {
            Copy-Item -LiteralPath (Join-Path $backup $rel) -Destination $target -Force
        } elseif (Test-Path -LiteralPath $target -PathType Leaf) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}

try {
    # Normalize only tracked source files after backing up originals. Old Slint
    # patches mixed CRLF/LF; git apply will not match their context otherwise.
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    foreach ($rel in $existing) {
        if ($rel -eq 'slint-experiment\Cargo.lock') { continue }
        $target = Join-Path $ProjectRoot $rel
        $value = [IO.File]::ReadAllText($target, [Text.Encoding]::UTF8)
        $value = $value.Replace("`r`n", "`n")
        [IO.File]::WriteAllText($target, $value, $utf8)
    }

    $ErrorActionPreference = 'Continue'
    & $git -C $ProjectRoot apply --reverse --check --ignore-whitespace $patch 2>$null
    $already = ($LASTEXITCODE -eq 0)
    if (!$already) {
        & $git -C $ProjectRoot apply --check --ignore-whitespace $patch 2>&1 | Out-Host
        $code = $LASTEXITCODE
        if ($code -ne 0) { throw "Patch does not match the selected source snapshot" }
        & $git -C $ProjectRoot apply --ignore-whitespace $patch 2>&1 | Out-Host
        $code = $LASTEXITCODE
        if ($code -ne 0) { throw "Patch application failed" }
    } else {
        Write-Host "Patch already present - checking build" -ForegroundColor Yellow
    }
    $ErrorActionPreference = 'Stop'

    $env:CARGO_INCREMENTAL = '1'
    $env:CARGO_BUILD_JOBS = '2'
    Push-Location (Join-Path $ProjectRoot 'slint-experiment')
    try {
        & $cargo build --bin overlay-host --jobs 2
        $code = $LASTEXITCODE
    } finally { Pop-Location }
    if ($code -ne 0) { throw "Cargo build failed, exit $code" }
    $exe = Join-Path $ProjectRoot 'slint-experiment\target\debug\overlay-host.exe'
    if (!(Test-Path $exe)) { throw "Built executable not found" }
    Write-Host "Build succeeded: $exe" -ForegroundColor Green
    Write-Host "Original sources backed up: $backup" -ForegroundColor Cyan
    Start-Process -FilePath $exe
}
catch {
    Restore-OriginalFiles
    Write-Warning "Source files restored from $backup. Existing Cargo target cache was not removed."
    throw
}
