# ASCII-only script for Windows PowerShell 5.1 and PowerShell 7.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$root = Join-Path $env:TEMP 'suflyor-codex-direct\suflyor-master'
$patch = Join-Path $PSScriptRoot 'debrief-retry.patch'
$manifest = Join-Path $root 'slint-experiment\Cargo.toml'
$exe = Join-Path $root 'slint-experiment\target\debug\overlay-host.exe'

if (!(Test-Path -LiteralPath $manifest -PathType Leaf)) { throw "Suflyor not found: $root" }
if (!(Test-Path -LiteralPath $patch -PathType Leaf)) { throw "Patch not found: $patch" }
$gitCommand = Get-Command git.exe -ErrorAction Stop
$cargoCommand = Get-Command cargo.exe -ErrorAction Stop
$git = $gitCommand.Source
$cargo = $cargoCommand.Source

# git can print benign stderr messages during --reverse --check. Do not let
# PowerShell 5.1 turn native stderr into a terminating NativeCommandError.
$ErrorActionPreference = 'Continue'
& $git -C $root apply --reverse --check $patch *> $null
$alreadyApplied = ($LASTEXITCODE -eq 0)
$ErrorActionPreference = 'Stop'

if ($alreadyApplied) {
    Write-Host 'Debrief retry patch is already applied. Running build.'
} else {
    $ErrorActionPreference = 'Continue'
    & $git -C $root apply --check $patch
    $checkCode = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if ($checkCode -ne 0) {
        throw 'Patch does not match the current source files. Nothing was changed. Please provide a new source ZIP.'
    }

    $backup = Join-Path $env:TEMP ('suflyor-debrief-retry-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $files = @(
        'overlay-backend\src\runtime.rs',
        'overlay-backend\src\conspect.rs',
        'overlay-backend\src\events.rs',
        'slint-experiment\src\bin\overlay_host_windows.rs'
    )
    foreach ($relative in $files) {
        $destination = Join-Path $backup $relative
        New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $root $relative) -Destination $destination -Force
    }
    Write-Host "Source backup: $backup"

    $ErrorActionPreference = 'Continue'
    & $git -C $root apply $patch
    $applyCode = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if ($applyCode -ne 0) {
        throw 'Patch apply failed. Backups are available. Cargo was not started.'
    }
    Write-Host 'Patch applied.'
}

# Retain the existing target directory, dependencies, debug profile and caches.
$env:CARGO_INCREMENTAL = '1'
$env:CARGO_BUILD_JOBS = '2'
Write-Host 'Building overlay-host (incremental debug)...'
$ErrorActionPreference = 'Continue'
& $cargo build --manifest-path $manifest --bin overlay-host
$buildCode = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
if ($buildCode -ne 0) {
    throw "Cargo build failed (exit $buildCode). Patch remains applied and Cargo cache is preserved."
}
if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw "Build succeeded, but EXE was not found: $exe" }
Write-Host 'Build successful. Launching Suflyor...'
Start-Process -FilePath $exe -WorkingDirectory $root
