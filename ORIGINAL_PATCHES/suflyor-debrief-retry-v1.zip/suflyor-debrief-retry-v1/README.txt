Suflyor — retry on AI failure for post-meeting coaching / debrief.

Works with the existing Slint error tile's Retry icon.
On AI failure the mic-side transcript is saved in the application's data
folder under debrief-retry/. No re-recording or STT is required.
Retry uses the currently configured AI endpoint. On successful coaching,
the retry payload is deleted. On session deletion it is deleted too.

Only future coaching failures receive the new Retry button. An already
opened error tile from an older executable cannot be modified retrospectively.

Run install.ps1 from an existing PowerShell console. No extra installer window.
This installer uses git apply, preserves Cargo cache, performs one incremental
debug build and starts overlay-host.exe only after successful compilation.

Validated offline: git apply --check, forward application, reverse check.
Windows compilation and live API calls not performed here.
