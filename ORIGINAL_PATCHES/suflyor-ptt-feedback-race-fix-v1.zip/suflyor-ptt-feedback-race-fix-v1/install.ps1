﻿param([switch]$NoBuild)
$ErrorActionPreference = 'Continue'
$root = Join-Path $env:TEMP 'suflyor-codex-direct\suflyor-master'
$patch = Join-Path $PSScriptRoot 'ptt-feedback-race.patch'
if (!(Test-Path (Join-Path $root 'slint-experiment\Cargo.toml'))) { throw "Suflyor not found: $root" }
if (!$NoBuild -and (Get-Process -Name 'overlay-host' -ErrorAction SilentlyContinue)) { throw 'Close Suflyor (overlay-host) before building.' }
$git = (Get-Command git.exe -ErrorAction Stop).Source
Push-Location $root
try {
    & $git apply --reverse --check --ignore-space-change -- $patch 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host 'PTT patch already applied; skipping.'
    } else {
        & $git apply --check --ignore-space-change -- $patch
        if ($LASTEXITCODE -ne 0) { throw 'PTT patch cannot apply to this Suflyor source; no files changed.' }
        $backupDir = Join-Path $env:TEMP ('suflyor-ptt-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        Copy-Item 'slint-experiment\ui\overlay_bar.slint' (Join-Path $backupDir 'overlay_bar.slint')
        Copy-Item 'slint-experiment\src\bin\overlay_host_windows.rs' (Join-Path $backupDir 'overlay_host_windows.rs')
        & $git apply --ignore-space-change -- $patch
        if ($LASTEXITCODE -ne 0) { throw 'git apply failed.' }
        # git apply can introduce LF lines in a CRLF working tree. Preserve the
        # original line ending style, or later Slint patches may fail.
        foreach ($entry in @(
            @('slint-experiment\ui\overlay_bar.slint', 'overlay_bar.slint'),
            @('slint-experiment\src\bin\overlay_host_windows.rs', 'overlay_host_windows.rs')
        )) {
            $file = Join-Path $root $entry[0]
            $backup = Join-Path $backupDir $entry[1]
            $original = [System.IO.File]::ReadAllText($backup, [System.Text.Encoding]::UTF8)
            $eol = if ($original.Contains("`r`n")) { "`r`n" } else { "`n" }
            $updated = [System.IO.File]::ReadAllText($file, [System.Text.Encoding]::UTF8)
            $updated = [regex]::Replace($updated, "`r`n|`r|`n", $eol)
            [System.IO.File]::WriteAllText($file, $updated, [System.Text.UTF8Encoding]::new($false))
        }
        Write-Host "PTT patch applied. Backups: $backupDir"
    }
    if (!$NoBuild) {
        $env:CARGO_INCREMENTAL = '1'
        $env:CARGO_BUILD_JOBS = '2'
        & cargo build --manifest-path '.\slint-experiment\Cargo.toml' --bin overlay-host
        if ($LASTEXITCODE -ne 0) { throw 'Cargo build failed. Files remain patched; cache untouched.' }
        $exe = Join-Path $root 'slint-experiment\target\debug\overlay-host.exe'
        if (!(Test-Path $exe)) { throw "Built exe not found: $exe" }
        Start-Process -FilePath $exe
    }
} finally { Pop-Location }
