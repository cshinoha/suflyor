PTT reliability fix: immediate press highlight; stale PCM cannot reset newer hold indicator; busy/empty capture feedback. Source patch applies to captured Suflyor tree; Rust build not executed here.
