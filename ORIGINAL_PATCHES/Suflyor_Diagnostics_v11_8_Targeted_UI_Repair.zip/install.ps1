﻿param(
    [string]$ProjectRoot = '',
    [switch]$NoLaunch
)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Suflyor-Recovered-v8-20261027-003608'
}
$ProjectRoot = [IO.Path]::GetFullPath($ProjectRoot)
$Project = Join-Path $ProjectRoot 'slint-experiment'
$Exe = Join-Path $Project 'target\debug\overlay-host.exe'
$BuildLog = Join-Path $ProjectRoot 'suflyor-v11.8-build.log'
$Receipt = Join-Path $ProjectRoot 'suflyor-v11.8-receipt.json'
$Version = 'v11.8'
$Items = @(
    @{ Name = 'network'; Rel = 'overlay-backend\src\network.rs' },
    @{ Name = 'stt'; Rel = 'overlay-backend\src\stt.rs' },
    @{ Name = 'diagnostics'; Rel = 'slint-experiment\src\bin\overlay_host\diagnostics.rs' },
    @{ Name = 'ui'; Rel = 'slint-experiment\ui\settings_panel.slint' }
)
function ReadSource([string]$Path) {
    $raw = [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8)
    return $raw.TrimStart([char]0xFEFF).Replace("`r`n", "`n")
}
function FileSha([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
}
# Patch ONLY four declarations and the diagnostics subpanel. Existing unrelated
# Slint settings remain byte-for-byte equivalent after newline normalization.
# All edit work is performed in memory, before any files are written.
function TargetedUi([string]$Current) {
    $s = $Current
    $declAnchor = '    callback diagnostics-collect-logs-clicked();'
    $defs = @(
        '    in-out property <string> diag-network-report: "";',
        '    in-out property <bool> diag-network-running: false;',
        '    callback diagnostics-network-check-clicked();',
        '    callback diagnostics-network-copy-clicked();'
    )
    $needs = @($defs | Where-Object { -not $s.Contains($_) })
    if ($needs.Count -gt 0) {
        if ([regex]::Matches($s, [regex]::Escape($declAnchor)).Count -ne 1) {
            throw 'UI incompatible: cannot uniquely find diagnostics callback declarations. No files changed.'
        }
        $s = $s.Replace($declAnchor, ($declAnchor + "`n" + ($needs -join "`n")))
    }
    $tabStart = $s.IndexOf('if root.active-tab == 13 : VerticalLayout {', [StringComparison]::Ordinal)
    if ($tabStart -lt 0) { throw 'UI incompatible: diagnostics tab (13) missing. No files changed.' }
    $db = $s.IndexOf('// ── База данных', $tabStart, [StringComparison]::Ordinal)
    if ($db -lt 0) { throw 'UI incompatible: diagnostics/database section boundary missing. No files changed.' }
    $oldCheck = $s.IndexOf('root.diagnostics-check-all-clicked();', $tabStart, [StringComparison]::Ordinal)
    if ($oldCheck -lt 0 -or $oldCheck -gt $db) { throw 'UI incompatible: Check all button missing before database section. No files changed.' }
    $diagButton = 'clicked => { root.diagnostics-network-check-clicked(); }'
    $buttonAt = $s.IndexOf($diagButton, $tabStart, [StringComparison]::Ordinal)
    if ($buttonAt -ge 0 -and $buttonAt -lt $db) {
        # Diagnostics UI is already installed by a prior attempt. Only adjust
        # its displayed version, leaving its layout and other settings alone.
        $labelPattern = 'AI / STT / Proxy: (?:подробная )?диагностика(?: v11\.[0-9]+)?'
        $matches = [regex]::Matches($s, $labelPattern)
        if ($matches.Count -eq 1) {
            $s = [regex]::Replace($s, $labelPattern, 'AI / STT / Proxy: диагностика v11.8')
        } else {
            throw 'UI partially installed: callback exists, but a unique diagnostics heading is missing. No files changed.'
        }
    } else {
        # Fail safe on partial UI — do not insert duplicate controls.
        $region = $s.Substring($tabStart, $db - $tabStart)
        if ($region.Contains('root.diag-network-report') -or
            $region.Contains('root.diagnostics-network-copy-clicked()') -or
            $region.Contains('Проверить модели и маршруты')) {
            throw 'UI partially installed: network diagnostics controls are incomplete. No files changed.'
        }
        $commentStart = $db - 24
        if ($commentStart -lt $tabStart -or
            $s.Substring($commentStart, 24) -cne '                        ') {
            throw 'UI incompatible: database comment indentation changed. No files changed.'
        }
        $subpanelPath = Join-Path $PSScriptRoot 'payload\ui_subpanel.txt'
        $subpanel = ReadSource $subpanelPath
        if (-not $subpanel.EndsWith("`n")) { $subpanel += "`n" }
        $s = $s.Insert($commentStart, $subpanel)
    }
    if (-not $s.Contains('callback diagnostics-network-check-clicked();') -or
        -not $s.Contains('callback diagnostics-network-copy-clicked();') -or
        -not $s.Contains('root.diagnostics-network-check-clicked();') -or
        -not $s.Contains('root.diagnostics-network-copy-clicked();') -or
        -not $s.Contains('AI / STT / Proxy: диагностика v11.8')) {
        throw 'UI incomplete after targeted edit. No files changed.'
    }
    return $s
}

if (Get-Process -Name 'overlay-host' -ErrorAction SilentlyContinue) {
    throw 'Close all Suflyor windows (overlay-host.exe) before installing.'
}
if (-not (Test-Path -LiteralPath (Join-Path $Project 'Cargo.toml'))) {
    throw "Cargo.toml missing: $Project"
}
$Cargo = (Get-Command 'cargo.exe' -ErrorAction Stop).Source
$Plan = @()
Write-Host "Project: $ProjectRoot" -ForegroundColor Cyan
foreach ($item in $Items) {
    $target = Join-Path $ProjectRoot $item.Rel
    $name = $item.Name
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing source: $target" }
    $b = ReadSource (Join-Path $PSScriptRoot "payload\base\$name.txt")
    $o = ReadSource (Join-Path $PSScriptRoot "payload\v11\$name.txt")
    $n = ReadSource (Join-Path $PSScriptRoot "payload\new\$name.txt")
    if ($name -eq 'diagnostics') {
        $n = $n.Replace('build=v11.7 begin', 'build=v11.8 begin')
    }
    $current = ReadSource $target
    $state = ''
    if ($current -ceq $n) { $state = 'up-to-date' }
    elseif ($current -ceq $b) { $state = 'update-from-base' }
    elseif ($current -ceq $o) { $state = 'update-from-v11' }
    elseif ($name -eq 'diagnostics' -and $current -ceq (ReadSource (Join-Path $PSScriptRoot 'payload\new\diagnostics.txt'))) { $state = 'update-diagnostic-stamp' }
    elseif ($name -eq 'ui') { $state = 'targeted-ui-repair' }
    else {
        # Non-UI files are still protected by exact-state matching.
        throw "Unknown source variant: $target (SHA256=$(FileSha $target)). Existing file untouched."
    }
    if ($name -eq 'ui') {
        $n = TargetedUi $current
        if ($current -ceq $n) { $state = 'up-to-date' }
        else { $state = 'targeted-ui-repair' }
    }
    $Plan += [pscustomobject]@{ Name=$name; Rel=$item.Rel; Path=$target; State=$state; New=$n; Old=$current }
    Write-Host "[$name] $state" -ForegroundColor Cyan
}
# Preflight confirms the bundled payload is structurally complete before
# touching any user file. No git apply, no fragile marker counting.
$uiData = ($Plan | Where-Object Name -eq 'ui' | Select-Object -First 1).New
$netData = ($Plan | Where-Object Name -eq 'network' | Select-Object -First 1).New
$diagData = ($Plan | Where-Object Name -eq 'diagnostics' | Select-Object -First 1).New
if (-not $uiData.Contains('AI / STT / Proxy: диагностика v11.8') -or
    -not $uiData.Contains('diagnostics-network-check-clicked') -or
    -not $netData.Contains('pub async fn diagnostic_probe(') -or
    -not $diagData.Contains('run_model_network_diagnostics') -or
    -not $diagData.Contains('build=v11.8 begin')) {
    throw 'Corrupt package: diagnostic payload incomplete.'
}
$toChange = @($Plan | Where-Object { $_.State -ne 'up-to-date' })
$backup = Join-Path $ProjectRoot ('patch-backups\diagnostics-v11.8-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
$beforeHash = if (Test-Path -LiteralPath $Exe -PathType Leaf) { FileSha $Exe } else { '' }
$oldIncremental = $env:CARGO_INCREMENTAL
$oldJobs = $env:CARGO_BUILD_JOBS
$modified = @()
try {
    foreach ($entry in $toChange) {
        $backupPath = Join-Path $backup $entry.Rel
        [IO.Directory]::CreateDirectory((Split-Path $backupPath -Parent)) | Out-Null
        Copy-Item -LiteralPath $entry.Path -Destination $backupPath -Force
        $modified += $entry
        # Write the full verified file, preserving the original newline format.
        $originalRaw = [IO.File]::ReadAllText($entry.Path, [Text.Encoding]::UTF8)
        $data = $entry.New
        if ($originalRaw.Contains("`r`n")) { $data = $data.Replace("`n", "`r`n") }
        [IO.File]::WriteAllText($entry.Path, $data, $utf8)
        if ((ReadSource $entry.Path) -cne $entry.New) {
            throw "Write verification failed: $($entry.Path)"
        }
        Write-Host "[$($entry.Name)] installed and verified" -ForegroundColor Green
    }
    $env:CARGO_INCREMENTAL='1'
    $env:CARGO_BUILD_JOBS='2'
    Write-Host 'Cargo incremental build (no clean, no fake file timestamps).' -ForegroundColor Cyan
    Write-Host "Log: $BuildLog" -ForegroundColor Cyan
    Push-Location $Project
    try {
        $oldPreference = $ErrorActionPreference
        $ErrorActionPreference = 'Continue' # rustc warnings appear on stderr in PowerShell 5.1
        try {
            & $Cargo build --bin overlay-host --jobs 2 --color never 2>&1 | Tee-Object -FilePath $BuildLog
            $code = $LASTEXITCODE
        } finally { $ErrorActionPreference = $oldPreference }
    } finally { Pop-Location }
    if ($code -ne 0) { throw "Cargo build failed (exit $code). See $BuildLog" }
    if (-not (Test-Path -LiteralPath $Exe -PathType Leaf)) { throw "No EXE: $Exe" }
    $afterHash = FileSha $Exe
    if ($toChange.Count -gt 0 -and $beforeHash -eq $afterHash) {
        throw "Sources updated but EXE SHA256 did not change. See $BuildLog"
    }
    # Keep the exact build path and digest so an older EXE can be recognized.
    $report = [ordered]@{
        version=$Version
        exe=$Exe
        exe_sha256=$afterHash
        exe_write_time_utc=(Get-Item -LiteralPath $Exe).LastWriteTimeUtc.ToString('o')
        changed_files=@($toChange | ForEach-Object { $_.Rel })
        build_log=$BuildLog
    }
    [IO.File]::WriteAllText($Receipt, ($report | ConvertTo-Json -Depth 5), $utf8)
    Write-Host 'SUCCESS: Cargo exited 0; verified sources and EXE.' -ForegroundColor Green
    Write-Host "EXE: $Exe" -ForegroundColor Green
    Write-Host "SHA256: $afterHash"
    Write-Host 'Visible label: AI / STT / Proxy: диагностика v11.8' -ForegroundColor Green
    if (-not $NoLaunch) { Start-Process -FilePath $Exe -WorkingDirectory $Project }
} catch {
    foreach ($entry in $modified) {
        $src = Join-Path $backup $entry.Rel
        if (Test-Path -LiteralPath $src) {
            Copy-Item -LiteralPath $src -Destination $entry.Path -Force
        }
    }
    if ($modified.Count -gt 0) {
        Write-Warning "Restored original source files from $backup; Cargo cache retained."
    }
    throw
} finally {
    $env:CARGO_INCREMENTAL=$oldIncremental
    $env:CARGO_BUILD_JOBS=$oldJobs
}
