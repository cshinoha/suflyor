﻿$ErrorActionPreference = 'Stop'
$root = Join-Path $env:TEMP 'suflyor-codex-direct\suflyor-master'
$ui = Join-Path $root 'slint-experiment\ui\overlay_bar.slint'
$manifest = Join-Path $root 'slint-experiment\Cargo.toml'
$exe = Join-Path $root 'slint-experiment\target\debug\overlay-host.exe'
if (!(Test-Path -LiteralPath $ui -PathType Leaf)) { throw "Source not found: $ui" }
if (!(Test-Path -LiteralPath $manifest -PathType Leaf)) { throw "Cargo manifest missing: $manifest" }
if (Get-Process -Name 'overlay-host' -ErrorAction SilentlyContinue) { throw 'Close the running Suflyor before installing (the debug EXE is locked). No changes made.' }
$cargo = (Get-Command cargo.exe -ErrorAction Stop).Source
$raw = [System.IO.File]::ReadAllBytes($ui)
$hadBom = $raw.Length -ge 3 -and $raw[0] -eq 239 -and $raw[1] -eq 187 -and $raw[2] -eq 191
$encoding = [System.Text.UTF8Encoding]::new($hadBom)
$text = [System.Text.Encoding]::UTF8.GetString($raw).TrimStart([char]0xFEFF)
$nl = if ($text.Contains("`r`n")) { "`r`n" } else { "`n" }
$pattern = '(?m)^(?<indent>[ \t]*)label: root\.smart-mode-active \? @tr\("SMART"\) : @tr\("NORMAL"\);\r?\n[ \t]*a11y: root\.smart-mode-active \? @tr\("AI mode: Smart"\) : @tr\("AI mode: Normal"\);\r?\n[ \t]*active: root\.smart-mode-active;\r?\n[ \t]*accent: #38bdf8;'
$matches = [regex]::Matches($text, $pattern)
$already = $text.Contains('label: root.smart-mode-active ? @tr("AI: УМНЫЙ") : @tr("AI: ОБЫЧНЫЙ");')
if ($matches.Count -eq 0 -and $already) {
    Write-Host 'Visible AI mode indicator already applied.' -ForegroundColor Cyan
} elseif ($matches.Count -ne 2) {
    throw "Unexpected overlay_bar.slint layout: found $($matches.Count) mode chips. Source unchanged."
} else {
    $replacement = [System.Text.RegularExpressions.MatchEvaluator] {
        param($m)
        $i = $m.Groups['indent'].Value
        return ($i + 'label: root.smart-mode-active ? @tr("AI: УМНЫЙ") : @tr("AI: ОБЫЧНЫЙ");' + $nl +
                $i + 'a11y: root.smart-mode-active ? @tr("Активен умный режим ИИ, нажмите для обычного") : @tr("Активен обычный режим ИИ, нажмите для умного");' + $nl +
                $i + 'active: true;' + $nl +
                $i + 'accent: root.smart-mode-active ? #38bdf8 : #a78bfa;')
    }
    $changed = [regex]::Replace($text, $pattern, $replacement)
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $backup = "$ui.bak-mode-$stamp"
    Copy-Item -LiteralPath $ui -Destination $backup -Force
    Write-Host "Backup: $backup"
    [System.IO.File]::WriteAllText($ui, $changed, $encoding)
    Write-Host 'AI mode chip updated in both full/compact bars.' -ForegroundColor Green
}
$env:CARGO_INCREMENTAL = '1'
$env:CARGO_BUILD_JOBS = '2'
Write-Host 'Building overlay-host, incremental debug...' -ForegroundColor Cyan
$ErrorActionPreference = 'Continue'
& $cargo build --manifest-path $manifest --bin overlay-host
$code = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
if ($code -ne 0) { throw "Cargo exited $code. Current source preserved, Cargo cache untouched." }
if (!(Test-Path -LiteralPath $exe)) { throw "EXE missing: $exe" }
Write-Host 'Build succeeded. Starting Suflyor...' -ForegroundColor Green
Start-Process -FilePath $exe -WorkingDirectory (Split-Path $exe -Parent)
